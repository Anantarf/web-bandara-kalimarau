<?php echo '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL; ?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
@foreach($urls as $url)
    <url>
        <loc>{{ $url->loc }}</loc>
        @if(!empty($url->lastmod))
            <lastmod>{{ $url->lastmod }}</lastmod>
        @endif
    </url>
@endforeach
</urlset>
