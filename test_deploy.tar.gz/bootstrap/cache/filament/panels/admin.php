<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.airport-stat-resource.pages.manage-airport-stats' => 'App\\Filament\\Resources\\AirportStatResource\\Pages\\ManageAirportStats',
    'app.filament.resources.audit-log-resource.pages.list-audit-logs' => 'App\\Filament\\Resources\\AuditLogResource\\Pages\\ListAuditLogs',
    'app.filament.resources.audit-log-resource.pages.view-audit-log' => 'App\\Filament\\Resources\\AuditLogResource\\Pages\\ViewAuditLog',
    'app.filament.resources.award-resource.pages.create-award' => 'App\\Filament\\Resources\\AwardResource\\Pages\\CreateAward',
    'app.filament.resources.award-resource.pages.edit-award' => 'App\\Filament\\Resources\\AwardResource\\Pages\\EditAward',
    'app.filament.resources.award-resource.pages.list-awards' => 'App\\Filament\\Resources\\AwardResource\\Pages\\ListAwards',
    'app.filament.resources.category-resource.pages.create-category' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\CreateCategory',
    'app.filament.resources.category-resource.pages.edit-category' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\EditCategory',
    'app.filament.resources.category-resource.pages.list-categories' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\ListCategories',
    'app.filament.resources.contact-message-resource.pages.create-contact-message' => 'App\\Filament\\Resources\\ContactMessageResource\\Pages\\CreateContactMessage',
    'app.filament.resources.contact-message-resource.pages.edit-contact-message' => 'App\\Filament\\Resources\\ContactMessageResource\\Pages\\EditContactMessage',
    'app.filament.resources.contact-message-resource.pages.list-contact-messages' => 'App\\Filament\\Resources\\ContactMessageResource\\Pages\\ListContactMessages',
    'app.filament.resources.facility-resource.pages.create-facility' => 'App\\Filament\\Resources\\FacilityResource\\Pages\\CreateFacility',
    'app.filament.resources.facility-resource.pages.edit-facility' => 'App\\Filament\\Resources\\FacilityResource\\Pages\\EditFacility',
    'app.filament.resources.facility-resource.pages.list-facilities' => 'App\\Filament\\Resources\\FacilityResource\\Pages\\ListFacilities',
    'app.filament.resources.flight-schedule-resource.pages.create-flight-schedule' => 'App\\Filament\\Resources\\FlightScheduleResource\\Pages\\CreateFlightSchedule',
    'app.filament.resources.flight-schedule-resource.pages.edit-flight-schedule' => 'App\\Filament\\Resources\\FlightScheduleResource\\Pages\\EditFlightSchedule',
    'app.filament.resources.flight-schedule-resource.pages.list-flight-schedules' => 'App\\Filament\\Resources\\FlightScheduleResource\\Pages\\ListFlightSchedules',
    'app.filament.resources.media-resource.pages.create-media' => 'App\\Filament\\Resources\\MediaResource\\Pages\\CreateMedia',
    'app.filament.resources.media-resource.pages.edit-media' => 'App\\Filament\\Resources\\MediaResource\\Pages\\EditMedia',
    'app.filament.resources.media-resource.pages.list-media' => 'App\\Filament\\Resources\\MediaResource\\Pages\\ListMedia',
    'app.filament.resources.page-resource.pages.create-page' => 'App\\Filament\\Resources\\PageResource\\Pages\\CreatePage',
    'app.filament.resources.page-resource.pages.edit-page' => 'App\\Filament\\Resources\\PageResource\\Pages\\EditPage',
    'app.filament.resources.page-resource.pages.list-pages' => 'App\\Filament\\Resources\\PageResource\\Pages\\ListPages',
    'app.filament.resources.post-resource.pages.create-post' => 'App\\Filament\\Resources\\PostResource\\Pages\\CreatePost',
    'app.filament.resources.post-resource.pages.edit-post' => 'App\\Filament\\Resources\\PostResource\\Pages\\EditPost',
    'app.filament.resources.post-resource.pages.list-posts' => 'App\\Filament\\Resources\\PostResource\\Pages\\ListPosts',
    'app.filament.resources.ppid-document-resource.pages.create-ppid-document' => 'App\\Filament\\Resources\\PpidDocumentResource\\Pages\\CreatePpidDocument',
    'app.filament.resources.ppid-document-resource.pages.edit-ppid-document' => 'App\\Filament\\Resources\\PpidDocumentResource\\Pages\\EditPpidDocument',
    'app.filament.resources.ppid-document-resource.pages.list-ppid-documents' => 'App\\Filament\\Resources\\PpidDocumentResource\\Pages\\ListPpidDocuments',
    'app.filament.resources.public-service-link-resource.pages.create-public-service-link' => 'App\\Filament\\Resources\\PublicServiceLinkResource\\Pages\\CreatePublicServiceLink',
    'app.filament.resources.public-service-link-resource.pages.edit-public-service-link' => 'App\\Filament\\Resources\\PublicServiceLinkResource\\Pages\\EditPublicServiceLink',
    'app.filament.resources.public-service-link-resource.pages.list-public-service-links' => 'App\\Filament\\Resources\\PublicServiceLinkResource\\Pages\\ListPublicServiceLinks',
    'app.filament.resources.redirect-resource.pages.manage-redirects' => 'App\\Filament\\Resources\\RedirectResource\\Pages\\ManageRedirects',
    'app.filament.resources.user-resource.pages.manage-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ManageUsers',
    'app.filament.pages.auth.login' => 'App\\Filament\\Pages\\Auth\\Login',
    'app.filament.pages.dashboard' => 'App\\Filament\\Pages\\Dashboard',
    'app.filament.widgets.latest-messages-widget' => 'App\\Filament\\Widgets\\LatestMessagesWidget',
    'app.filament.widgets.stats-overview' => 'App\\Filament\\Widgets\\StatsOverview',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament\\Pages\\Dashboard.php' => 'App\\Filament\\Pages\\Dashboard',
    0 => 'App\\Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament\\Resources\\AirportStatResource.php' => 'App\\Filament\\Resources\\AirportStatResource',
    'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament\\Resources\\AuditLogResource.php' => 'App\\Filament\\Resources\\AuditLogResource',
    'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament\\Resources\\AwardResource.php' => 'App\\Filament\\Resources\\AwardResource',
    'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament\\Resources\\CategoryResource.php' => 'App\\Filament\\Resources\\CategoryResource',
    'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament\\Resources\\ContactMessageResource.php' => 'App\\Filament\\Resources\\ContactMessageResource',
    'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament\\Resources\\FacilityResource.php' => 'App\\Filament\\Resources\\FacilityResource',
    'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament\\Resources\\FlightScheduleResource.php' => 'App\\Filament\\Resources\\FlightScheduleResource',
    'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament\\Resources\\MediaResource.php' => 'App\\Filament\\Resources\\MediaResource',
    'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament\\Resources\\PageResource.php' => 'App\\Filament\\Resources\\PageResource',
    'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament\\Resources\\PostResource.php' => 'App\\Filament\\Resources\\PostResource',
    'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament\\Resources\\PpidDocumentResource.php' => 'App\\Filament\\Resources\\PpidDocumentResource',
    'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament\\Resources\\PublicServiceLinkResource.php' => 'App\\Filament\\Resources\\PublicServiceLinkResource',
    'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament\\Resources\\RedirectResource.php' => 'App\\Filament\\Resources\\RedirectResource',
    'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament\\Resources\\UserResource.php' => 'App\\Filament\\Resources\\UserResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament\\Widgets\\LatestMessagesWidget.php' => 'App\\Filament\\Widgets\\LatestMessagesWidget',
    'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament\\Widgets\\StatsOverview.php' => 'App\\Filament\\Widgets\\StatsOverview',
    0 => 'Filament\\Widgets\\AccountWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\Users\\Ananta Raihan\\Downloads\\kalimarau\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);